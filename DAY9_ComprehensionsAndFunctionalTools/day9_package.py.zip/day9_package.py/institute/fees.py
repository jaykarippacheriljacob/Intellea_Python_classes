def display_fee(course_fee,discount):
    return course_fee - discount