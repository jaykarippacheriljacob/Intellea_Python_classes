def display_student(name):
    print("student name",name)