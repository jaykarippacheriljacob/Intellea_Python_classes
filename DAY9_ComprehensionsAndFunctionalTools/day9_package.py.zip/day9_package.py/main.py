from institute.students import display_student
from institute.fees import display_fee

display_student("Arun")
final_amount = display_fee(25000,2000)
print(final_amount)
