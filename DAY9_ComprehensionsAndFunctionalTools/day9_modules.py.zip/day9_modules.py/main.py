# import calculator as c
# print("addition",c.add(10,20))
# print("subtract",c.subtract(30,10))

from calculator import add,subtract
print(add(10,20))
print(subtract(30,10))
